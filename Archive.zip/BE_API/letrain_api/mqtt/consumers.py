from flask import jsonify, request
import json

# from ..model.db.trigger import Trigger
from ..config import Config
from letrain_api import myMqtt
from ..service.trigger.calculate_triggers import CalculateTriggers

calculate_triggers = CalculateTriggers()

@myMqtt.on_connect()
def handle_connect(client, userdata, flags, rc):
    print('Connected to MQTT broker')
    myMqtt.subscribe(f'{Config.MQTT_TOPIC_TRIGGER_RECALCULATION}')
    print(f'subscribed to {Config.MQTT_TOPIC_TRIGGER_RECALCULATION}')

@myMqtt.on_message()
def handle_mqtt_message(client, userdata, message):
    print(f'Received message: {message.topic}: {message.payload.decode()}')
    if message.topic == Config.MQTT_TOPIC_TRIGGER_RECALCULATION:
        try:
            payload = json.loads(message.payload.decode())
            calculate_triggers.calculate_trigger(payload)
            print('trigger ' + payload['name'] + ' recalculated')
        except json.JSONDecodeError:
            calculate_triggers.calculate_all()
            print('All triggers recalculated')
