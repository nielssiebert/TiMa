from marshmallow import Schema, fields, validate, validates_schema, ValidationError

from ...service.valid.valve_validator import ValveValidator
from ...service.valid.trigger_validator import TriggerValidator

valve_validator = ValveValidator()
trigger_validator = TriggerValidator()

class ValveSchema(Schema):
    id = fields.Str(required=True, validate=validate.Length(min=1))
    name = fields.Str(required=True, validate=validate.Length(min=1))
    io_pin = fields.Int(required=True)
    status = fields.Str(required=True, validate=validate.OneOf(['ON', 'OFF']))
    duration_ms = fields.Int(required=True, validate=validate.Range(min=0, max=2147483647))
    high_to_switch_on = fields.Bool(required=True)
    activated = fields.Bool(required=False, dump_only=True)
    triggers = fields.List(fields.Pluck('TriggerSchema', 'id'), dump_only=True)

    @validates_schema
    def validate_io_pin(self, data, **kwargs):
        if 'id_' in data and 'io_pin' in data:
            valve_validator.validate_pin_change(id=data['id'], io_pin=data['io_pin'])

class ValveActivateValidation(Schema):
    id = fields.Str(required=True, validate=[validate.Length(min=1), valve_validator.validate_activation])

class ValveActiveValidation(Schema):
    id = fields.Str(required=True, validate=[validate.Length(min=1), valve_validator.validate_active])