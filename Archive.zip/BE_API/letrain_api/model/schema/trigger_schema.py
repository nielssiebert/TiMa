from marshmallow import Schema, fields, validate, validates_schema, ValidationError
from marshmallow_enum import EnumField
from sqlalchemy import Date

from letrain_api.model.schema.factor_schema import FactorSchema
from letrain_api.model.schema.valve_group_schema import ValveGroupSchema
from letrain_api.model.schema.valve_schema import ValveSchema

from ..db.trigger import Trigger

from ..enums import DayOfWeek, TriggerType, ExecutionType, RecurranceType
from ...service.valid.trigger_validator import TriggerValidator
from ...service.valid.valve_validator import ValveValidator
from ...service.valid.valve_group_validator import ValveGroupValidator
from ...service.valid.factor_validator import FactorValidator

trigger_validator = TriggerValidator()
valve_validator = ValveValidator()
valve_group_validator = ValveGroupValidator()
factor_validator = FactorValidator()

class TriggerExecutionOrderSchema(Schema):
    trigger_id = fields.Str(required=True)
    order = fields.Int(required=True)
    valve_id = fields.Nested(ValveSchema)
    valve_group_id = fields.Nested(ValveGroupSchema)

class TriggerSchema(Schema):
    class Meta:
        Trigger

    id = fields.Str(required=True, validate=validate.Length(min=1))
    name = fields.Str(required=True, validate=validate.Length(min=1))
    date = fields.Date(required=False, allow_none=True, validate=validate.Range(min=lambda: Date.today()))
    time = fields.Time(required=True, format='%H:%M:%S')
    weekdays = fields.List(fields.String(validate=validate.OneOf([day.value for day in DayOfWeek])), required=False)
    from_date = fields.Date(required=False, allow_none=True)
    to_date = fields.Date(required=False, allow_none=True)
    activated = fields.Bool(required=False, dump_only=True)
    trigger_type = EnumField(TriggerType, by_value=False, required=True)
    execution_type = EnumField(ExecutionType, by_value=False, required=True)
    recurrance_type = EnumField(RecurranceType, by_value=False, required=False)
    # trigger_type = fields.Str(required=True, validate=validate.OneOf([trigger_type.name for trigger_type in TriggerType]))
    # execution_type = fields.Str(required=True, validate=validate.OneOf([execution_type.name for execution_type in ExecutionType]))
    # recurrance_type = fields.Str(required=False, validate=validate.OneOf([recurrance_type.name for recurrance_type in RecurranceType]))
    valves = fields.List(fields.Nested(ValveSchema), dump_only=True)
    valve_groups = fields.List(fields.Nested(ValveGroupSchema), dump_only=True)
    factors = fields.List(fields.Nested(FactorSchema), dump_only=True)
    execution_orders = fields.List(
        fields.Nested(TriggerExecutionOrderSchema),
        dump_only=True)
    
    @validates_schema
    def validate_date(self, data, **kwargs):
        if data['execution_type'] == RecurranceType.ONE_TIME.name and data['date'] is None:
            raise ValidationError("Failure: Date must be provided for one time trigger")
        
    @validates_schema
    def validate_weekdays(self, data, **kwargs):
        if data['execution_type'] == RecurranceType.WEEKLY.name and (data['weekdays'] is None or len(data['weekdays']) == 0):
            raise ValidationError("Failure: Weekdays must be provided for weekly trigger")


    # @validates_schema
    # def validate_execution_order(self, data, **kwargs):
    #     trigger_validator.validate_execution_order(data['execution_orders'], valves=data['valves'], valve_groups=data['valve_groups'])
