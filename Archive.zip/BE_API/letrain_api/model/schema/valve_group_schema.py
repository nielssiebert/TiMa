from marshmallow import Schema, fields, validate, validates_schema, ValidationError

from .valve_schema import ValveSchema

from ...model.db.valve_group import ValveGroup

from ...service.valid.valve_validator import ValveValidator
from ...service.valid.trigger_validator import TriggerValidator

valve_validator = ValveValidator()
trigger_validator = TriggerValidator()

class ValveGroupSchema(Schema):
    class Meta:
        ValveGroup

    id = fields.Str(required=True, validate=validate.Length(min=1))
    name = fields.Str(required=True, validate=validate.Length(min=1))
    valves = fields.List(fields.Nested(ValveSchema), dump_only=True)
    triggers = fields.List(fields.Pluck('TriggerSchema', 'id'), dump_only=True)
