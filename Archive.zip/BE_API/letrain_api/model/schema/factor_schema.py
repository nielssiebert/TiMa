from marshmallow import Schema, fields, validate, validates_schema, ValidationError
from sqlalchemy import Date

from letrain_api.model.db.factor import Factor

from ...service.valid.trigger_validator import TriggerValidator
from ...service.valid.valve_validator import ValveValidator
from ...service.valid.valve_group_validator import ValveGroupValidator
from ...service.valid.factor_validator import FactorValidator

trigger_validator = TriggerValidator()
valve_validator = ValveValidator()
valve_group_validator = ValveGroupValidator()
factor_validator = FactorValidator()

class FactorSchema(Schema):
    class Meta:
        model = Factor

    id = fields.Str(required=True, validate=validate.Length(min=1))
    name = fields.Str(required=True, validate=validate.Length(min=1))
    factor = fields.Float(required=True, validate=validate.Range(min=0.0000000001, max=100000000.0))
    triggers = fields.List(fields.Pluck('TriggerSchema', 'id'), dump_only=True)
    