from enum import Enum

class ValveStatus(Enum):
    ON = 1
    OFF = 0

class TriggerType(Enum):
    START_AT_POINT_IN_TIME = 0
    STOP_AT_POINT_IN_TIME = 1

class ExecutionType(Enum):
    SERIAL = 0
    PARALLEL = 1

class DayOfWeek(Enum):
    SUNDAY = "so"
    MONDAY = "mo"
    TUESDAY = "tu"
    WEDNESDAY = "we"
    THURSDAY = "th"
    FRIDAY = "fr"
    SATURDAY = "sa"

class RecurranceType(Enum):
    TIMER = 0
    ONE_TIME = 1
    WEEKLY = 2