from typing import List

from letrain_api.model.db.factor import Factor
from letrain_api.model.db.valve import Valve
from letrain_api.model.db.valve_group import ValveGroup
from .trigger_execution_order import TriggerExecutionOrder
from ... import db
from .associations import trigger_factor_association, valve_trigger_association, valve_group_trigger_association
from ...model.enums import TriggerType, ExecutionType, RecurranceType

class Trigger(db.Model):
    id = db.Column(db.String, primary_key=True)
    name = db.Column(db.String, nullable=False)
    date = db.Column(db.Date, nullable=True)
    time = db.Column(db.Time, nullable=True)
    weekdays = db.Column(db.JSON, nullable=True)
    from_date = db.Column(db.Date, nullable=True)
    to_date = db.Column(db.Date, nullable=True)
    activated = db.Column(db.Boolean, nullable=False, default=True)
    trigger_type = db.Column(db.Enum(TriggerType), nullable=False, default=TriggerType.START_AT_POINT_IN_TIME.name)
    execution_type = db.Column(db.Enum(ExecutionType), nullable=False, default=ExecutionType.SERIAL.name)
    recurrance_type = db.Column(db.Enum(RecurranceType), nullable=False)
    execution_orders = db.relationship('TriggerExecutionOrder', back_populates='trigger')
    valves = db.relationship('Valve', secondary=valve_trigger_association, back_populates='triggers')
    valve_groups = db.relationship('ValveGroup', secondary=valve_group_trigger_association, back_populates='triggers')
    factors = db.relationship('Factor', secondary=trigger_factor_association, back_populates='triggers')
