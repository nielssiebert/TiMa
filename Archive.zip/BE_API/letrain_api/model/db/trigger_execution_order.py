from ... import db

class TriggerExecutionOrder(db.Model):
    trigger_id = db.Column(db.String, db.ForeignKey('trigger.id'), nullable=False, primary_key=True)
    trigger = db.relationship('Trigger', back_populates='execution_orders')
    order = db.Column(db.Integer, nullable=False, primary_key=True)
    valve_id = db.Column(db.String, db.ForeignKey('valve.id'))
    valve = db.relationship('Valve')
    valve_group_id = db.Column(db.String, db.ForeignKey('valve_group.id'))
    valve_group = db.relationship('ValveGroup')