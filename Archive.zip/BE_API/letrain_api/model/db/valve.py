from datetime import timedelta
from ... import db
from .associations import valve_trigger_association, valve_valve_group_association

class Valve(db.Model):
    id = db.Column(db.String, primary_key=True)
    name = db.Column(db.String, nullable=False)
    io_pin = db.Column(db.Integer, nullable=False)
    status = db.Column(db.Enum('ON', 'OFF'), default='OFF')
    duration_ms = db.Column(db.BigInteger, nullable=False, default=int(timedelta(minutes=10).total_seconds() * 1000))
    high_to_switch_on = db.Column(db.Boolean, default=True)
    activated = db.Column(db.Boolean, default=False)
    valve_groups = db.relationship('ValveGroup', secondary=valve_valve_group_association, back_populates='valves')
    triggers = db.relationship('Trigger', secondary=valve_trigger_association, back_populates='valves')

    # def get_duration(self):
    #     return timedelta(milliseconds=self.duration_ms)

    # def set_duration(self, duration: timedelta):
    #     self.duration_ms = int(duration.total_seconds() * 1000)
