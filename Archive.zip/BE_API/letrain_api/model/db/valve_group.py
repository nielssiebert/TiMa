from typing import List

from letrain_api.model.db.valve import Valve
from ... import db
from .associations import valve_group_trigger_association, valve_valve_group_association

class ValveGroup(db.Model):
    id = db.Column(db.String, primary_key=True)
    name = db.Column(db.String, nullable=False)
    valves = db.relationship('Valve', secondary=valve_valve_group_association, back_populates='valve_groups')
