from letrain_api import scheduler
from ..config import Config
from ..service.trigger.calculate_triggers import CalculateTriggers
from letrain_api import myMqtt

calculate_triggers = CalculateTriggers()

@scheduler.task('interval', id='calculate_triggers', seconds=Config.REFRESH_INTERVAL, misfire_grace_time=10)
def calculate_all_triggers():
    print("task calculate_all_triggers executed")
    myMqtt.publish(str(Config.MQTT_TOPIC_TRIGGER_RECALCULATION), 'recalculate')
