from functools import wraps

def validate_execution_order(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        # Find the execution_order parameter
        print(f"Arguments were: {args}, {kwargs}")
        execution_order = kwargs.get('execution_order', None)
        
        # Validate execution_order
        if execution_order is None:
            raise ValueError("execution_order parameter is required.")
        if (execution_order.valve is None and execution_order.valve_group is None):
            raise ValueError("execution_order must have either a valve or a valve_group assigned.")
        if execution_order.valve is not None and execution_order.valve_group is not None:
            raise ValueError("execution_order cannot have both a valve and a valve_group assigned.")
        return func(*args, **kwargs)
    return wrapper