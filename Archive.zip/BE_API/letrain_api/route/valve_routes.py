from flask import Blueprint
from ..model.schema.valve_schema import ValveActivateValidation, ValveSchema, ValveActiveValidation
from ..validation.common_validation import validate_POST_schema
from ..auth import auth
from ..converter.valve_converter import ValveConverter
from ..service.valve.valve_service import ValveService

valve_bp = Blueprint('main', __name__)
valve_converter = ValveConverter()
valve_service = ValveService()


@valve_bp.route('/valves', methods=['GET'])
@auth.login_required
def get_valves():
    return valve_service.get_valves()

@valve_bp.route('/valves/<id>', methods=['GET'])
@auth.login_required
def get_valve(id):
    return valve_service.get_valve(id)

@valve_bp.route('/valves', methods=['POST'])
@auth.login_required
@validate_POST_schema(ValveSchema)
def create_or_update_valve(validated_valve):
    return valve_service.create_or_update_valve(validated_valve)

@valve_bp.route('/valves/<id>', methods=['DELETE'])
@auth.login_required
def delete_valve(id):
    return valve_service.delete_valve(id)

@valve_bp.route('/valves/switch_on', methods=['POST'])
@auth.login_required
@validate_POST_schema(ValveActiveValidation)
def switch_valve_on(identifiable):
    return valve_service.switch_valve_on(identifiable['id'])

@valve_bp.route('/valves/switch_off', methods=['POST'])
@auth.login_required
@validate_POST_schema(ValveActiveValidation)
def switch_valve_off(identifiable):
    return valve_service.switch_valve_off(identifiable['id'])

@valve_bp.route('/valves/activate', methods=['POST'])
@auth.login_required
@validate_POST_schema(ValveActivateValidation)
def activate_valve(identifiable):
    return valve_service.activate(identifiable['id'])

@valve_bp.route('/valves/deactivate', methods=['POST'])
@auth.login_required
@validate_POST_schema(ValveActiveValidation)
def deactivate_valve(identifiable):
    return valve_service.deactivate(identifiable['id'])
