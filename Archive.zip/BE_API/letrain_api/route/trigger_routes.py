from flask import Blueprint

from ..model.schema.trigger_schema import TriggerSchema
from ..auth import auth
from ..service.trigger.trigger_service import TriggerService
from ..validation.common_validation import validate_POST_schema

trigger_bp = Blueprint('trigger_bp', __name__)
trigger_service = TriggerService()

@trigger_bp.route('/triggers', methods=['GET'])
@auth.login_required
def get_triggers():
    return trigger_service.get_all_triggers()

@trigger_bp.route('/triggers/<unique_name>', methods=['GET'])
@auth.login_required
def get_trigger(unique_name):
    return trigger_service.get_trigger_by_id(unique_name)

@trigger_bp.route('/triggers', methods=['POST'])
@auth.login_required
@validate_POST_schema(TriggerSchema)
def create_or_update_trigger(validated_trigger):
    return trigger_service.create_or_update_trigger(validated_trigger)

@trigger_bp.route('/triggers/<unique_name>', methods=['DELETE'])
@auth.login_required
def delete_trigger(unique_name):
    return trigger_service.delete_trigger(unique_name)