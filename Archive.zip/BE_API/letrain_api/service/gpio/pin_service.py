import RPi.GPIO as GPIO

# gpio = GPIO

class PinService:
    def __init__(self):
        self.gpio = GPIO
        self.gpio.setmode(GPIO.BCM)
        print("PinService initialized")

    def init_pin(self, pin, high_on_init):
        # self.gpio.setmode(GPIO.BCM)
        self.gpio.setup(pin, GPIO.OUT)
        self.gpio.output(pin, GPIO.HIGH if high_on_init else GPIO.LOW)

    def get_pin_status(self, pin):
 #       gpio.setmode(GPIO.BCM)
 #       gpio.setup(pin, GPIO.IN)
 #       pin_status = GPIO.input(pin)
 #       gpio.cleanup()
        return # pin_status
    
    def set_pin_status(self, pin, status):
        print("Setting pin status: ", status, pin)
        self.gpio.setup(pin, GPIO.OUT)
        self.gpio.output(pin, status)
        return
    
    def shut_down_pin(self, pin):
        print("shutting down pin: ", pin)
        self.gpio.setup(pin, GPIO.IN)