from marshmallow import ValidationError

from ...model.db.valve_group import ValveGroup
from ...model.db.valve import Valve

class ValveGroupValidator:
    pass

    def validate_exists(self, id):
        db_valve_group = ValveGroup.query.get(id)
        if db_valve_group is None:
            raise ValidationError("Failure: ValveGroup does not exist")
        return id