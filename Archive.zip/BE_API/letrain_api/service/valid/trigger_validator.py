from typing import List

from ...model.db.trigger import Trigger
from marshmallow import ValidationError

class TriggerValidator:
    pass

    def triggers_exist(self, triggers):
        for trigger in triggers:
            if not Trigger.query.get(trigger):
                raise ValidationError("Failure: Trigger does not exist")
            
    def validate_execution_order(self, orders, valves, valve_groups): 
        for execution_order in orders:
            if not Trigger.query.get(execution_order.trigger_id):
                raise ValidationError("Failure: Trigger does not exist")
            if not isinstance(execution_order.order, int):
                raise ValidationError("Failure: Order is not an integer")
            if not (execution_order.valve or execution_order.valve_group):
                raise ValidationError("Failure: valve or valve_group must be provided")
            if execution_order.valve and execution_order.valve_group:
                raise ValidationError("Failure: valve and valve_group cannot be provided at the same time")
            if execution_order.valve and not valves.count(lambda v: v.id == execution_order.valve.id) > 0:
                raise ValidationError("Failure: Valve is not added to List of valves")
            if execution_order.valve_group and not valve_groups.count(lambda vg: vg.id == execution_order.valve_group.id) > 0:
                raise ValidationError("Failure: ValveGroup is not added to List of valve_groups")
            if orders.count(lambda o: o.order == execution_order.order) > 1:
                raise ValidationError("Failure: Duplicate order")
        return orders