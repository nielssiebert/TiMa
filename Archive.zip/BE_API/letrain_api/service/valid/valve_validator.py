from marshmallow import ValidationError
from ...model.db.valve import Valve

class ValveValidator:
    pass

    def validate_activation(self, id):
        db_valve = Valve.query.get_or_404(id)
        valves_with_same_pin = Valve.query.filter_by(io_pin=db_valve.io_pin).filter(Valve.id!=id).all()
        for other_valve in valves_with_same_pin:
            if other_valve.activated:
                raise ValidationError("Failure: Valve with same pin already activated")

    def validate_pin_change(self, id, io_pin):
        if io_pin < 0 or io_pin > 40:
            raise ValidationError("Failure: Invalid GPIO pin number")

        db_valve: Valve = Valve.query.get(id)
        if (db_valve is None) or (db_valve.io_pin == io_pin):
            return io_pin
        
        if db_valve.activated:
            raise ValidationError("Failure: Valve is activated and cannot be changed")
        
        return io_pin
    
    def validate_active(self, id):
        db_valve = Valve.query.get_or_404(id)
        if not db_valve.activated:
            raise ValidationError("Failure: Valve is not activated")
        return id
    
    def validate_exists(self, id):
        db_valve = Valve.query.get(id)
        if db_valve is None:
            raise ValidationError("Failure: Valve does not exist")
        return db_valve