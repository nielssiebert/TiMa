from marshmallow import ValidationError

from ...model.db.factor import Factor

class FactorValidator:
    pass

    def validate_exists(self, id):
        db_factor = Factor.query.get(id)
        if db_factor is None:
            raise ValidationError("Failure: Factor does not exist")
        return db_factor