import datetime
from ...service.gpio.valve_status_service import ValveStatusService
from .strategy.after_stop_strategy import AfterStopStrategy, after_stop_strategy_map
from letrain_api.model.enums import ValveStatus
from letrain_api import scheduler
from letrain_api import app
from letrain_api import myMqtt
from ...model.db.trigger import Trigger

valve_status_service = ValveStatusService()
# calculate_triggers = CalculateTriggers()

class CalculateTriggersUtil:
    def schedule_valve(self, trigger, factor, valve, start_time_offset):
            next_start_time = self.schedule_trigger(trigger, valve, start_time_offset)
            duration = datetime.timedelta(seconds=valve.duration.total_seconds() * factor)
            self.add_start_job(next_start_time, valve)
            self.add_stop_job(trigger, next_start_time + duration, valve)
            return duration

    def add_stop_job(self, trigger, stop_time, valve):
        scheduler.add_job(id='stop_valve_' + valve.id, func=self.stop_valve, args=[valve, trigger], trigger='date', run_date=stop_time)

    def add_start_job(self, start_time, valve):
        scheduler.add_job(id='start_valve_' + valve.id, func=self.start_valve, args=[valve], trigger='date', run_date=start_time)

    def schedule_trigger(self, trigger, valve, start_time_offset):
        time = trigger.time
        date = trigger.date or datetime.date.today()
        if time < datetime.datetime.now().time():
            date = date + datetime.timedelta(days=1)
        start_time = datetime.datetime.combine(date, time)
        start_time += start_time_offset
        return start_time

    def start_valve(self, valve, trigger: Trigger):
        with app.app_context():
            valve_status_service.set_valve_status(valve, ValveStatus.ON)
        return

    def stop_valve(self, valve, trigger: Trigger):
        with app.app_context():
            valve_status_service.set_valve_status(valve, ValveStatus.OFF)
            strategy: AfterStopStrategy = after_stop_strategy_map.get(trigger.execution_type, None)
            if strategy is None:
                raise Exception("No strategy found for trigger")
            strategy.after_stop(trigger, valve)
            print("stop valve")
            myMqtt.publish('functional.recalculate.triggers', trigger)
        return
