# import datetime
# from ...model.db.trigger import Trigger
# from ...service.gpio.valve_status_service import ValveStatusService
# from .calculate_factors_util import CalculateFactorsUtil
# from abc import ABC, abstractmethod
# from ...validation.decorator import validate_execution_order
# from ...model.enums import ExecutionType
# from ..gpio.valve_status_service import ValveStatusService
# from .strategy.after_stop_strategy import AfterStopStrategy, after_stop_strategy_map
# from letrain_api import scheduler
# from letrain_api import app
# from letrain_api import myMqtt
# from letrain_api.model.enums import ValveStatus

# valve_status_service = ValveStatusService()
# calculate_factors_util = CalculateFactorsUtil()

# class CalculateTriggers:

#     def calculate_all(self):
#         with app.app_context():
#             triggers = Trigger.query.filter(Trigger.activated == True).all()
#             triggers_with_order = filter(lambda trigger: len(trigger.execution_orders) > 0, triggers)
#             for trigger in triggers_with_order:
#                 self.calculate_trigger(trigger)
#         return

#     def calculate_trigger(self, trigger: Trigger):
#         if trigger.activated == False:
#             return
#         factor = calculate_factors_util.calculate_factors(trigger)
#         strategy: SchedulingStrategy = scheduling_strategy_map.get(trigger.execution_type, None)
#         if strategy is None:
#             raise Exception("No strategy found for trigger")
#         start_time_offset = datetime.timedelta(seconds=0)
#         for execution_order in trigger.execution_order:
#             start_time_offset = strategy.schedule(trigger, factor, execution_order, start_time_offset)

#     def schedule_valve(self, trigger, factor, valve, start_time_offset):
#         next_start_time = self.schedule_trigger(trigger, valve, start_time_offset)
#         duration = datetime.timedelta(seconds=valve.duration.total_seconds() * factor)
#         self.add_start_job(next_start_time, valve)
#         self.add_stop_job(trigger, next_start_time + duration, valve)
#         return duration

#     def add_stop_job(self, trigger, stop_time, valve):
#         scheduler.add_job(id='stop_valve_' + valve.id, func=self.stop_valve, args=[valve, trigger], trigger='date', run_date=stop_time)

#     def add_start_job(self, start_time, valve):
#         scheduler.add_job(id='start_valve_' + valve.id, func=self.start_valve, args=[valve], trigger='date', run_date=start_time)

#     def schedule_trigger(self, trigger, valve, start_time_offset):
#         time = trigger.time
#         date = trigger.date or datetime.date.today()
#         if time < datetime.datetime.now().time():
#             date = date + datetime.timedelta(days=1)
#         start_time = datetime.datetime.combine(date, time)
#         start_time += start_time_offset
#         return start_time
    
#     def start_valve(self, valve, trigger: Trigger):
#         with app.app_context():
#             valve_status_service.set_valve_status(valve, ValveStatus.ON)
#         return
    
#     def stop_valve(self, valve, trigger: Trigger):
#         with app.app_context():
#             valve_status_service.set_valve_status(valve, ValveStatus.OFF)
#             strategy: AfterStopStrategy = after_stop_strategy_map.get(trigger.execution_type, None)
#             if strategy is None:
#                 raise Exception("No strategy found for trigger")
#             strategy.after_stop(trigger, valve)
#             # self.calculate_trigger(trigger)
#             myMqtt.publish('functional.recalculate.triggers', trigger)
#         return

# class SchedulingStrategy(ABC):
#     @abstractmethod
#     def schedule_valve_group(self, trigger, factor, execution_order, start_time_offset):
#         pass

#     @abstractmethod
#     def schedule_valve(self, trigger, factor, execution_order, start_time_offset):
#         pass

#     @validate_execution_order
#     def schedule(self, trigger, factor, execution_order, start_time_offset):
#         if execution_order.valve is not None:
#             return self.schedule_valve(trigger, factor, execution_order, start_time_offset)
#         else:
#             return self.schedule_valve_group(trigger, factor, execution_order, start_time_offset)

# calculate_triggers = CalculateTriggers()

# class SerialSchedulingStrategy(SchedulingStrategy):
#     def schedule_valve(self, trigger, factor, execution_order, start_time_offset):
#         duration = calculate_triggers.schedule_valve(trigger, factor, execution_order.valve, start_time_offset)
#         start_time_offset += duration
#         return start_time_offset

#     def schedule_valve_group(self, trigger, factor, execution_order, start_time_offset):
#             # max_duration = 0
#             # for valve in execution_order.valve_group.valves:
#             #     duration = calculate_triggers_util.schedule_valve(trigger, factor, valve, start_time_offset)
#             #     if duration > max_duration:
#             #         max_duration = duration
#             # start_time_offset += max_duration
#         valve_durations = [
#             calculate_triggers.schedule_valve(trigger, factor, valve, start_time_offset)
#             for valve in execution_order.valve_group.valves
#         ]
#         max_duration = max(valve_durations, default=0)
#         start_time_offset += max_duration
#         return start_time_offset
    
# class ParallelSchedulingStrategy(SchedulingStrategy):
#     @validate_execution_order
#     def schedule_valve(self, trigger, factor, execution_order, start_time_offset):
#         calculate_triggers.schedule_valve(trigger, factor, execution_order.valve, start_time_offset)
#         return start_time_offset
        
#     def schedule_valve_group(self, trigger, factor, execution_order, start_time_offset):
#         for valve in execution_order.valve_group.valves:
#             calculate_triggers.schedule_valve(trigger, factor, valve, start_time_offset)
#         return start_time_offset

# scheduling_strategy_map = {
#     ExecutionType.SERIAL: SerialSchedulingStrategy,
#     ExecutionType.PARALLEL: ParallelSchedulingStrategy
# }
