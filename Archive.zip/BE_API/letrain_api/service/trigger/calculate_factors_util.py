

class CalculateFactorsUtil:

    def calculate_factors(self, trigger):
        product_of_factors = 1
        for factor in trigger.factors:
            product_of_factors *= factor.value
        return product_of_factors