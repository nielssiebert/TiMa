from ...model.db.trigger import Trigger
from ...model.schema.trigger_schema import TriggerSchema
from flask import jsonify
from ... import db

class TriggerService:
    def get_all_triggers(self):
        triggers = Trigger.query.all()
        triggers_schema = TriggerSchema(many=True)
        return triggers_schema.dump(triggers)

    def get_trigger_by_id(self, id):
        trigger = Trigger.query.get_or_404(id)
        trigger_schema = TriggerSchema(many=False)
        return trigger_schema.dump(trigger)

    def create_or_update_trigger(self, validated_trigger):
        exists = db.session.query(Trigger.id).filter_by(id=validated_trigger['id']).first() is not None
        if exists:
            return self.update_trigger(validated_trigger)
        return self.create_trigger(validated_trigger)
    
    def create_trigger(self, data):
        new_trigger = Trigger(**data)
        db.session.add(new_trigger)
        db.session.commit()
        trigger = Trigger.query.get(data['id'])
        trigger_schema = TriggerSchema(many=False)
        return trigger_schema.dump(trigger)

    def update_trigger(self, validated_trigger):
        trigger = Trigger.query.get_or_404(validated_trigger['id'])
        for key, value in validated_trigger.items():
            setattr(trigger, key, value)
        db.session.commit()
        trigger_schema = TriggerSchema(many=False)
        return trigger_schema.dump(trigger)
    
    def delete_trigger(self, unique_name):
        trigger = Trigger.query.get_or_404(unique_name)
        db.session.delete(trigger)
        db.session.commit()
        return '', 204