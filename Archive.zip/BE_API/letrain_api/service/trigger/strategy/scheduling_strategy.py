from abc import ABC, abstractmethod
from ....validation.decorator import validate_execution_order
from ....model.enums import ExecutionType
# from ...gpio.valve_status_service import ValveStatusService
from ..calculate_triggers_util import CalculateTriggersUtil

# valve_status_service = ValveStatusService()
calculate_triggers_util = CalculateTriggersUtil()
# calculate_triggers = CalculateTriggers()

class SchedulingStrategy(ABC):
    @abstractmethod
    def schedule_valve_group(self, trigger, factor, execution_order, start_time_offset):
        pass

    @abstractmethod
    def schedule_valve(self, trigger, factor, execution_order, start_time_offset):
        pass

    @validate_execution_order
    def schedule(self, trigger, factor, execution_order, start_time_offset):
        if execution_order.valve is not None:
            return self.schedule_valve(trigger, factor, execution_order, start_time_offset)
        else:
            return self.schedule_valve_group(trigger, factor, execution_order, start_time_offset)

class SerialSchedulingStrategy(SchedulingStrategy):
    def schedule_valve(self, trigger, factor, execution_order, start_time_offset):
        duration = calculate_triggers_util.schedule_valve(trigger, factor, execution_order.valve, start_time_offset)
        start_time_offset += duration
        return start_time_offset

    def schedule_valve_group(self, trigger, factor, execution_order, start_time_offset):
        valve_durations = [
            calculate_triggers_util.schedule_valve(trigger, factor, valve, start_time_offset)
            for valve in execution_order.valve_group.valves
        ]
        max_duration = max(valve_durations, default=0)
        start_time_offset += max_duration
        return start_time_offset
    
class ParallelSchedulingStrategy(SchedulingStrategy):
    @validate_execution_order
    def schedule_valve(self, trigger, factor, execution_order, start_time_offset):
        calculate_triggers_util.schedule_valve(trigger, factor, execution_order.valve, start_time_offset)
        return start_time_offset
        
    def schedule_valve_group(self, trigger, factor, execution_order, start_time_offset):
        for valve in execution_order.valve_group.valves:
            calculate_triggers_util.schedule_valve(trigger, factor, valve, start_time_offset)
        return start_time_offset

scheduling_strategy_map = {
    ExecutionType.SERIAL: SerialSchedulingStrategy,
    ExecutionType.PARALLEL: ParallelSchedulingStrategy
}