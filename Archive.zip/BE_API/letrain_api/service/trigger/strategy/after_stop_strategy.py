from abc import ABC, abstractmethod
from ....model.enums import RecurranceType
from ...gpio.valve_status_service import ValveStatusService
from letrain_api import db

valve_status_service = ValveStatusService()

class AfterStopStrategy(ABC):
    @abstractmethod
    def after_stop(self, trigger, valve):
        pass

class OneTimeAfterStopStrategy(AfterStopStrategy):
    def after_stop(self, trigger, valve):
        trigger.activated = False
        db.session.commit()
        return

class TimerAfterStopStrategy(AfterStopStrategy):
    def after_stop(self, trigger, valve):
        trigger.activated = False
        db.session.commit()
        return
    
class WeeklyAfterStopStrategy(AfterStopStrategy):
    def after_stop(self, trigger, valve):
        return
    
after_stop_strategy_map = {
    RecurranceType.ONE_TIME: OneTimeAfterStopStrategy,
    RecurranceType.TIMER: TimerAfterStopStrategy,
    RecurranceType.WEEKLY: WeeklyAfterStopStrategy
}