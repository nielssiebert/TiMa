import datetime
from ...model.db.trigger import Trigger
from ...service.gpio.valve_status_service import ValveStatusService
from .calculate_factors_util import CalculateFactorsUtil
from .strategy.scheduling_strategy import SchedulingStrategy, scheduling_strategy_map
from ..gpio.valve_status_service import ValveStatusService
from letrain_api import app
# from letrain_api.model.enums import ValveStatus

valve_status_service = ValveStatusService()
calculate_factors_util = CalculateFactorsUtil()

class CalculateTriggers:

    def calculate_all(self):
        with app.app_context():
            triggers = Trigger.query.filter(Trigger.activated == True).all()
            triggers_with_order = filter(lambda trigger: len(trigger.execution_orders) > 0, triggers)
            for trigger in triggers_with_order:
                self.calculate_trigger(trigger)
        return

    def calculate_trigger(self, trigger: Trigger):
        if trigger.activated == False:
            return
        factor = calculate_factors_util.calculate_factors(trigger)
        strategy: SchedulingStrategy = scheduling_strategy_map.get(trigger.execution_type, None)
        if strategy is None:
            raise Exception("No strategy found for trigger")
        start_time_offset = datetime.timedelta(seconds=0)
        for execution_order in trigger.execution_order:
            start_time_offset = strategy.schedule(trigger, factor, execution_order, start_time_offset)

    