from flask import request, jsonify


from ...service.gpio.valve_status_service import ValveStatusService
from ... import db
from ...model.schema.valve_schema import ValveSchema
from ...model.db.valve import Valve
from ...model.enums import ValveStatus
from ...converter.valve_converter import ValveConverter
from ..gpio.pin_service import PinService

valve_converter = ValveConverter()
valve_status_service = ValveStatusService()
pin_service = PinService()

class ValveService:
    pass

    def get_valve(self, id):
        valve = Valve.query.get_or_404(id)
        valve_schema = ValveSchema(many=False)
        return valve_schema.dump(valve)
    
    def get_valves(self):
        valves = Valve.query.all()
        valve_schema = ValveSchema(many=True)
        return valve_schema.dump(valves)

    def create_or_update_valve(self, validated_valve):
        exists = db.session.query(Valve.id).filter_by(id=validated_valve['id']).first() is not None
        if exists:
            return self.update_valve(validated_valve['id'])
        return self.create_valve(validated_valve)

    def update_valve(self, id):
        valve = Valve.query.get_or_404(id)
        data = request.get_json()
        for key, value in data.items():
            setattr(valve, key, value)
        db.session.commit()
        return jsonify(valve_converter.to_dict(valve))


    def create_valve(self, validated_valve):
        new_valve = Valve(**validated_valve)
        db.session.add(new_valve)
        db.session.commit()
        return jsonify(valve_converter.to_dict(new_valve)), 201
    
    def delete_valve(self, id):
        valve = Valve.query.get_or_404(id)
        db.session.delete(valve)
        db.session.commit()
        return '', 204
    
    def switch_valve_on(self, id):
        valve = Valve.query.get_or_404(id)
        valve_status_service.set_valve_status(valve, ValveStatus.ON)
        setattr(valve, 'status', 'ON')
        db.session.commit()
        return jsonify({'status': 'switched on'})

    def switch_valve_off(self, id):
        valve = Valve.query.get_or_404(id)
        valve_status_service.set_valve_status(valve, ValveStatus.OFF)
        setattr(valve, 'status', 'OFF')
        db.session.commit()
        return jsonify({'status': 'switched off'})

    def activate(self, id):
        valve = Valve.query.get_or_404(id)
        setattr(valve, 'activated', True)
        valve_status_service.init_valve_pin(valve)
        db.session.commit()
        return jsonify({'status': 'activated'})
    
    def deactivate(self, id):
        valve = Valve.query.get_or_404(id)
        valve.activated = False
        pin_service.shut_down_pin(valve.io_pin)
        db.session.commit()
        return jsonify({'status': 'deactivated'})