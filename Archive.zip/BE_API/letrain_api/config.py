class Config:
    BASE_PATH = '/letrain'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///letrain.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    ENABLE_AUTH = False  # Toggle authentication
    SCHEDULER_API_ENABLED = True
    REFRESH_INTERVAL = 5.0  # seconds
    START_STOP_CHECK_INTERVAL = 0.2  # seconds

    # MQTT
    MQTT_BROKER_URL = 'localhost'
    MQTT_BROKER_PORT = 1883
    MQTT_KEEPALIVE = 60
    MQTT_TLS_ENABLED = False

    # Topics
    MQTT_TOPIC_PREFIX = 'letrain.'
    MQTT_TOPIC_TRIGGER_RECALCULATION = f'{MQTT_TOPIC_PREFIX}functional.recalculate.triggers'