from .trigger_converter import TriggerConverter
from ..model.db.valve_group import ValveGroup

trigger_converter = TriggerConverter()

class ValveGroupConverter:

    def to_dict(self, valve: ValveGroup):
        return {
            'id': valve.id,
            'name': valve.name,
            'status': valve.status,
            'io_pin': valve.io_pin,
            'duration_ms': valve.duration_ms,
            'activated': valve.activated,
            'high_to_switch_on': valve.high_to_switch_on,
            'triggers': [trigger_converter.to_dict(trigger) for trigger in valve.triggers]
        }