from .factor_converter import FactorConverter
from ..model.db.trigger import Trigger

factor_converter = FactorConverter()

class TriggerConverter:
    pass
    
    def to_dict(self, trigger: Trigger):
        return {
            'id': trigger.id,
            'name': trigger.name,
            'date': trigger.date,
            'time': trigger.time,
            'weekdays': trigger.weekdays,
            'from_date': trigger.from_date,
            'to_date': trigger.to_date,
            'activated': trigger.activated,
            'trigger_type': trigger.trigger_type,
            'execution_type': trigger.execution_type,
            'recurrance_type': trigger.recurrance_type,
            'execution_orders': [execution_order_converter.to_dict(execution_order) for execution_order in trigger.execution_orders],
            'valve_groups': [valve_group_converter.to_dict(valve_group) for valve_group in trigger.valve_groups],
            'valves': [{'id': valve.id, 'name': valve.name} for valve in trigger.valves],
            'factors': [factor_converter.to_dict(factor) for factor in trigger.factors]
        }