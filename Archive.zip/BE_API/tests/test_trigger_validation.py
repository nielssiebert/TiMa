import pytest
from marshmallow import ValidationError
from unittest.mock import patch
from letrain_api.validation.trigger_validation import validate_triggers_exist
from letrain_api.model.db.trigger import Trigger
from letrain_api import create_app

@pytest.fixture(scope='module')
def test_app():
    app = create_app()
    with app.app_context():
        yield app

def test_validate_triggers_exist_all_exist(test_app):
    triggers = ['trigger1', 'trigger2']
    with patch.object(Trigger.query, 'filter_by') as mock_filter_by:
        mock_filter_by.return_value.first.side_effect = [True, True]
        validate_triggers_exist(triggers)

def test_validate_triggers_exist_some_missing(test_app):
    triggers = ['trigger1', 'trigger2']
    with patch.object(Trigger.query, 'filter_by') as mock_filter_by:
        mock_filter_by.return_value.first.side_effect = [True, None]
        with pytest.raises(ValidationError) as excinfo:
            validate_triggers_exist(triggers)
        assert 'Triggers not found: trigger2' in str(excinfo.value)

def test_validate_triggers_exist_all_missing(test_app):
    triggers = ['trigger1', 'trigger2']
    with patch.object(Trigger.query, 'filter_by') as mock_filter_by:
        mock_filter_by.return_value.first.side_effect = [None, None]
        with pytest.raises(ValidationError) as excinfo:
            validate_triggers_exist(triggers)
        assert 'Triggers not found: trigger1, trigger2' in str(excinfo.value)