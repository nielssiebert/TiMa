import pytest
from letrain_api import create_app, db

@pytest.fixture(scope='module')
def test_app():
    app = create_app('testing')
    with app.app_context():
        yield app

@pytest.fixture(scope='module')
def test_client(test_app):
    return test_app.test_client()

@pytest.fixture(scope='module')
def init_database(test_app):
    db.create_all()
    yield db
    db.drop_all()