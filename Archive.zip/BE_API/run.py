from letrain_api import create_app, db
import sys
import os

# # Add the project root to the PYTHONPATH
# sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

app_api = create_app()

if __name__ == "__main__":
    app_api.run(host="0.0.0.0", port=5000, debug=True)

with app_api.app_context():
    from letrain_api.service.gpio.valve_status_service import ValveStatusService
    valve_status_service = ValveStatusService()
    valve_status_service.init_valve_pins()