from app import create_app, db

app_api = create_app()

if __name__ == "__main__":
    app_api.run(host="0.0.0.0", port=5000, debug=True)

with app_api.app_context():
    from app.service.gpio.valve_status_service import ValveStatusService
    valve_status_service = ValveStatusService()
    valve_status_service.init_valve_pins()