# from ...model.db.trigger import Trigger
# from ...service.gpio.valve_status_service import ValveStatusService
# from .calculate_factors_util import CalculateFactorsUtil
# from .trigger_util import calculate_trigger

# valve_status_service = ValveStatusService()
# calculate_factors_util = CalculateFactorsUtil()

# class CalculateTriggers:

#     def calculate(self):
#         triggers = Trigger.query.filter(Trigger.activated == True).filter(Trigger.execution_orders.length > 0).all()
#         for trigger in triggers:
#             calculate_trigger(trigger)
#         return

    # def calculate_trigger(self, trigger: Trigger):
    #     if trigger.activated == False:
    #         return
    #     factor = calculate_factors_util.calculate_factors(trigger)
    #     strategy: SchedulingStrategy = scheduling_strategy_map.get(trigger.execution_type, None)
    #     if strategy is None:
    #         raise Exception("No strategy found for trigger")
    #     start_time_offset = datetime.timedelta(seconds=0)
    #     for execution_order in trigger.execution_order:
    #         start_time_offset = strategy.schedule(trigger, factor, execution_order, start_time_offset)
