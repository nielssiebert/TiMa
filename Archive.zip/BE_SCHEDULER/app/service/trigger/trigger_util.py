# trigger_utils.py
# import datetime

# from app.model.enums import ValveStatus
# from app.model.enums import ExecutionType
# from .strategy.scheduling_strategy import SchedulingStrategy, scheduling_strategy_map
# from .strategy.after_stop_strategy import after_stop_strategy_map
# from .calculate_factors_util import CalculateFactorsUtil
# from ...service.gpio.valve_status_service import ValveStatusService

# valve_status_service = ValveStatusService()
# calculate_factors_util = CalculateFactorsUtil()

# def start_valve(valve, trigger):
#     valve_status_service.set_valve_status(valve, ValveStatus.ON)
#     return

# def stop_valve(valve, trigger):
#     valve_status_service.set_valve_status(valve, ValveStatus.OFF)
#     strategy = after_stop_strategy_map.get(trigger.recurrance_type, None)
#     if strategy is None:
#         raise Exception("No strategy found for trigger")
#     strategy.after_stop(trigger, valve)
#     calculate_trigger(trigger)
#     return

# def calculate_factors(trigger):
#     product_of_factors = 1
#     for factor in trigger.factors:
#         product_of_factors *= factor.value
#     return product_of_factors

# def calculate_trigger(trigger):
#     if trigger.activated == False:
#         return
#     factor = calculate_factors(trigger)
#     strategy: SchedulingStrategy = scheduling_strategy_map.get(trigger.execution_type, None)
#     if strategy is None:
#         raise Exception("No strategy found for trigger")
#     start_time_offset = datetime.timedelta(seconds=0)
#     for execution_order in trigger.execution_order:
#         start_time_offset = strategy.schedule(trigger, factor, execution_order, start_time_offset)
