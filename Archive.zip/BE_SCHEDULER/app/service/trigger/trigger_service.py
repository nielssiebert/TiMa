from letrain_api.model.db.trigger import Trigger
from flask import jsonify
from ... import db

class TriggerService:
    def get_all_triggers(self):
        triggers = Trigger.query.all()
        return jsonify([trigger for trigger in triggers])

    def get_trigger_by_id(self, id):
        trigger = Trigger.query.get_or_404(id)
        return jsonify(trigger)

    def create_or_update_trigger(self, validated_trigger):
        exists = db.session.query(Trigger.id).filter_by(id=validated_trigger['id']).first() is not None
        if exists:
            return self.update_trigger(validated_trigger['id'])
        return self.create_trigger(validated_trigger)
    
    def create_trigger(self, data):
        new_trigger = Trigger(**data)
        db.session.add(new_trigger)
        db.session.commit()
        return jsonify(new_trigger), 201

    def update_trigger(self, unique_name, data):
        trigger = Trigger.query.get_or_404(unique_name)
        for key, value in data.items():
            setattr(trigger, key, value)
        db.session.commit()
        return jsonify(trigger)
    
    def delete_trigger(self, unique_name):
        trigger = Trigger.query.get_or_404(unique_name)
        db.session.delete(trigger)
        db.session.commit()
        return '', 204