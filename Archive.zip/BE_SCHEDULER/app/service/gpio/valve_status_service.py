import RPi.GPIO as GPIO
# from flask import Flask

from letrain_api.model.db.valve import Valve
from letrain_api.model.enums import ValveStatus
from ..gpio.pin_service import PinService
from app import app

# app = Flask(__name__)
pin_service = PinService()

class NoGPIOPinAssignedException(Exception):
    pass

class ValveStatusService:
    def __init__(self):
        print("ValveStatusService initialized")
    
    def init_valve_pins(self):
        with app.app_context():
            self.valves = Valve.query.all()
            for valve in self.valves:
                self.init_valve_pin(valve)
        print("Valve pins initialized")

    def init_valve_pin(self, valve):
        self.ensure_io_pin_assigned(valve)
        pin_service.init_pin(valve.io_pin, valve.high_to_switch_on!=True)


    def valve_switched_on(self, valve: Valve):
        self.ensure_io_pin_assigned(valve)
        
        pin_status = self.get_pin_status(valve.io_pin)

        if ((pin_status == GPIO.HIGH) and valve.high_to_switch_on) or ((pin_status == GPIO.LOW) and not valve.high_to_switch_on):
            return ValveStatus.ON
        else:
            return ValveStatus.OFF

    def set_valve_status(self, valve: Valve, status: ValveStatus):
        self.ensure_io_pin_assigned(valve)
        ## TODO: implement valve history
        if status == ValveStatus.ON:
            pin_service.set_pin_status(valve.io_pin, GPIO.HIGH if valve.high_to_switch_on else GPIO.LOW)
        else:
            pin_service.set_pin_status(valve.io_pin, GPIO.LOW if valve.high_to_switch_on else GPIO.HIGH)
        

    def ensure_io_pin_assigned(self, valve):
        if valve.io_pin is None:
            raise NoGPIOPinAssignedException("Failure: No GPIO pin assigned to valve")