from app import scheduler
from ..config import Config
from ..service.trigger.calculate_triggers_aio import CalculateTriggers

calculate_triggers = CalculateTriggers()

@scheduler.task('interval', id='calculate_triggers', seconds=Config.REFRESH_INTERVAL, misfire_grace_time=10)
def calculate_all_triggers():
    print("calculate_all_triggers executed")
    calculate_triggers.calculate()

# @scheduler.task('interval', id='find_start_triggers', seconds=Config.START_STOP_CHECK_INTERVAL, misfire_grace_time=10)
# def find_start_triggers():
#     return

# @scheduler.task('interval', id='find_stop_triggers', seconds=Config.START_STOP_CHECK_INTERVAL, misfire_grace_time=10)
# def find_stop_triggers():
#     return