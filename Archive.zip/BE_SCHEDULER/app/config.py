class Config:
    BASE_PATH = '/letrain'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///letrain.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    ENABLE_AUTH = False  # Toggle authentication
    SCHEDULER_API_ENABLED = True
    REFRESH_INTERVAL = 5.0  # seconds
    START_STOP_CHECK_INTERVAL = 0.2  # seconds