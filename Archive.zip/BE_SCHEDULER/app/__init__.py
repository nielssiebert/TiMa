from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_apscheduler import APScheduler
from .config import Config

app = Flask(__name__)
db = SQLAlchemy()
scheduler = APScheduler()

def create_app():
    app.config.from_object(Config)

    db.init_app(app)
    
    scheduler.init_app(app)
    scheduler.start()

    with app.app_context():
        from .scheduled import tasks

    return app